
/**
 * Created by deepak on 6/4/2017.
 */

function layOutDay(events) {
    
        //This is to reset DOM every time layOutDay is called
        document.getElementById("calender").innerHTML=".";
        var events_size = events.length;
        var event, i, j;
        var a=0;
        var timeslots = [];
        
        //Sorting by start time
        events = events.sort(function(a, b){return a.start - b.start;});
        
        events = update(events);
        append_div(events);
        return events;
};



function append_div(eventArr) {
  var i = 0;
  while (i < eventArr.length) {
    var event_div = document.createElement('div');
    event_div.className = 'event';
    event_div.style.height = eventArr[i].height;
    event_div.style.top = eventArr[i].top;
    event_div.style.background = eventArr[i].color;
    event_div.style.width = eventArr[i].width;
    event_div.style.left = eventArr[i].left;
//    event_div.innerHTML = 'Sample Item';
    var str = '<br>';
//    event_div.innerHTML = str;
//    event_div.innerHTML = 'Sample Location';
    event_div.style.color="#55AC8A";
    event_div.style.borderLeft = "10px solid #55AC8A";
    event_div.style.paddingLeft="5px";
    event_div.style.boxSizing="border-box";
    event_div.style.borderLeft = "solid #55AC8A";

            event_div.style.fontFamily="Arial,Helvetica";
            event_div.style.fontSize = "13px";
            event_div.style.marginLeft="10px";
//            div.style.marginRight="10px";
    
    var t = document.createTextNode("  Sample Item");

            event_div.appendChild(t);   // Create a text node
            var br = document.createElement("br");
            event_div.appendChild(br);

            var myspan = document.createElement("span");
            let  te = document.createTextNode("  Sample Location");
            myspan.style.color="black";
            myspan.appendChild(te);
            event_div.appendChild(myspan);

    var cl = document.getElementById('calender');
    cl.appendChild(event_div);
    i++;
  }
}

function check_collision_data(a, b) {
  return a.end > b.start && a.start < b.end;
}

function checkCollision(eventArr) {
  for (var i = 0; i < eventArr.length; i++) {
    eventArr[i].cols = [];
    eventArr[i].previous_col=[];
    for (var j = 0; j < eventArr.length; j++) {
      if (check_collision_data(eventArr[i], eventArr[j])) {
        eventArr[i].cols.push(j);
        if(i>j) eventArr[i].previous_col.push(j); //also list which of the conflicts came before
      }
    }
  }
  return eventArr;
}

function update(eventArr) {
  eventArr = checkCollision(eventArr);
  var arr=eventArr.slice(0); //clone the array
  for(var i=0; i<arr.length; i++){
  	var el=arr[i];
    el.color = "#FFFFFF";
    el.height = (el.end - el.start) + 'px';
    el.top = (el.start) + 'px';
    
    if(i>0 && el.previous_col.length>0){ //check column if no collisions occur
    	if(arr[i-1].column>0){ 
      	for(var j=0;j<arr[i-1].column;j++){ 
        	if(el.previous_col.indexOf(i-(j+2))===-1){ 
          	el.column=arr[i-(j+2)].column; 
          }
        }
        if(typeof el.column==='undefined') el.column=arr[i-1].column+1;  
      }else{
      	var column=0;
        for(var j=0;j<el.previous_col.length;j++){ 
          if(arr[el.previous_col[el.previous_col.length-1-j]].column==column) column++;
        }
      	el.column=column;
      }
    }else el.column=0;
  }
    
  //check col number to determine max width
  for(var i=0; i<arr.length; i++){
 		arr[i].totalColumns=0;
      
    // if loop checks collision
  	if(arr[i].cols.length>1){ 
      var conflictGroup=[]; 
      var cols_conflict=[]; 
      add_conflict_together(arr[i]);
      function add_conflict_together(a){
        for(k=0;k<a.cols.length;k++){
          if(conflictGroup.indexOf(a.cols[k])===-1){ 
            conflictGroup.push(a.cols[k]);
            cols_conflict.push(arr[a.cols[k]].column);
            add_conflict_together(arr[a.cols[k]]); 
          }
        }
      }
        //calculate max no of cols
      arr[i].totalColumns=Math.max.apply(null, cols_conflict); 
    }
    arr[i].width=(600/(arr[i].totalColumns+1))+'px';
    arr[i].left=(600/(arr[i].totalColumns+1)*arr[i].column)+'px';
  }
  return arr;
}